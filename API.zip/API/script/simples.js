document.addEventListener('DOMContentLoaded', () => {
    const inputPesquisar = document.getElementById('input-pesquisar');
    const btnPesquisar = document.getElementById('btn-pesquisar');
    const pokename = document.getElementById('pokename');
    const imgElement = document.getElementById('imgChange');
    
    

    async function buscar(identificadorPokemon) {
        if (!identificadorPokemon || identificadorPokemon.trim() === "") {
            alert("Erro: Nenhum Pokémon foi informado!");
            return;
        }

        try {
            console.log("Buscando Pokémon:", identificadorPokemon);

            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${identificadorPokemon.toLowerCase()}`);

            if (!response.ok) {
                throw new Error(`Erro ${response.status}: Pokémon não encontrado!`);
            }

            const pokemon = await response.json();
            console.log("Pokémon encontrado:", pokemon);

            var pokemonNome = pokemon.name;
            if (pokename) {
                pokename.textContent = pokemonNome;
                var temp = "img/generation-5/"+inputPesquisar.value+".png"
                imgElement.src = temp;
            }

        } catch (error) {
            console.error("Erro ao buscar Pokémon:", error);
            alert("Erro ao buscar Pokémon: " + error.message);
        }
    }

    // 🔹 Evento de clique no botão buscar
    btnPesquisar.addEventListener('click', () => {
        const nomeOuId = inputPesquisar.value.trim(); // Captura o valor digitado no input
        buscar(nomeOuId); // Passa o valor para a função buscar()
    });

    // 🔹 Evento para permitir pesquisa ao pressionar "Enter"
    inputPesquisar.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            btnPesquisar.click(); // Simula um clique no botão
        }
    });
});
