package com.example.calcularimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {


    private BreakIterator inputpeso;
    BreakIterator inputAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularIMC(View view) {

        double peso = Double.parseDouble(inputpeso.getText().toString());

        double altura = Double.parseDouble(inputAltura.getText().toString());
        double imc = peso / (altura * altura);

        String classificacao = "";
        if (imc < 18.5) {
            classificacao = "Baixo peso";
        } else if (imc >= 18.5 && imc < 25) {
            classificacao = "Peso normal";
        } else if (imc >= 25 && imc < 30) {
            classificacao = "Sobrepeso";
        } else {
            classificacao = "Obesidade";
        }
        


    }

}
